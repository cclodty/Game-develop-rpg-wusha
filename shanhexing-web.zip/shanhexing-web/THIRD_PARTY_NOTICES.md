# 素材來源

## Dialogue Manager

使用 Nathan Hoad 的 [Dialogue Manager v3.10.4](https://github.com/nathanhoad/godot_dialogue_manager/releases/tag/v3.10.4)，授權為 MIT。完整上游授權保存在 addons/dialogue_manager/LICENSE；瀏覽器下載包另附 licenses/DialogueManager-LICENSE.txt。固定來源、commit 與雜湊見 docs/DEPENDENCIES.md 及 docs/dialogue_manager.lock.json。

## Noto CJK 字體

assets/fonts/JianghuSans.otf 與 JianghuSerif.otf 來自 Noto Sans CJK TC / Noto Serif CJK TC，經子集處理並重新命名。授權為 SIL Open Font License 1.1；完整授權與來源說明包含在：

- assets/fonts/LICENSE-NOTO.txt
- assets/fonts/README.md

## 原創內容

本專案的地點、角色、事件、對話、門派與合成音樂為此作品新作。沒有使用《金庸群俠傳3》的程式、人物立繪、文本、音樂或其他遊戲資產。

assets/generated/ 內的角色、場景、道具、門派圖示與遊戲圖標以 OpenAI image generation 為本專案生成；後續素材參照同一組角色美術，以保持一致畫風。原始 PNG 保留不變，由 Godot 的 AtlasTexture 在執行時選取對應區域。美術規範與圖集排列見 docs/ART_DIRECTION.md。

assets/art/ 保留早期原創 SVG 草稿供原始碼參考，目前遊戲不使用，亦不包含在 Web 匯出中。

## 引擎

Godot Engine 使用 MIT License，參見 <https://godotengine.org/license/>。匯出的遊戲使用 Godot 執行環境；發行時請保留適用的引擎及第三方授權資訊。
